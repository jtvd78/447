extern char kversion[];
