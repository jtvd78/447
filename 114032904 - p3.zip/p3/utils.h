
extern void PUT32 ( unsigned long, unsigned long );
extern unsigned long GET32 ( unsigned long );
extern void * GETPC ( void );
extern void idle ( void );
extern void dummy ( void );
extern long cpu_id ( void );
