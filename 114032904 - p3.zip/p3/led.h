
extern void init_led();
extern void led_on();
extern void led_off();
extern void blink_led_stall(unsigned int reps);
extern void blink_led_tq(unsigned int reps);

