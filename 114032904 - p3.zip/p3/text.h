
#define DEAD	0xdeadbeef

long atol_dec(char *s);
long atol_hex(char *s);
char * tokenize(char *s, char);
void strcpy4(char *to, char *from);
int strcpyN(char *to, char *from, int bufsiz);

