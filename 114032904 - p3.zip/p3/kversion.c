char kversion[] = "Kernel version: [p3, Fri Mar 1 00:18:15 STD 2019]";
