
extern void do_hex( namenum_t data );
extern void do_blink( namenum_t data );
extern void do_string( namenum_t data );
extern void do_butter( namenum_t data );
