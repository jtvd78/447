
extern void PUT32 ( unsigned int, unsigned int );
extern unsigned int GET32 ( unsigned int );
extern void * GETPC ( void );
extern void idle ( void );
extern unsigned long get_core ( void );
