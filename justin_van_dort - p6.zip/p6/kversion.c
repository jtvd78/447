char kversion[] = "Kernel version: [p6, Sun Apr 14 17:29:13 DST 2019]";
