
extern void led_on();
extern void led_off();
extern void blink_led(unsigned int reps);

