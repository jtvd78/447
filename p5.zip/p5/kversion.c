char kversion[] = "Kernel version: [p5, Sun Mar 31 20:29:12 DST 2019]";
